# Screeps AI #

This my AI for the game [screeps.com](http://www.screeps.com). The grunt script is taken basically as is from [the screeps support wiki](http://support.screeps.com/hc/en-us/articles/203022512-Commiting-local-scripts-using-Grunt).

# Usage #

Make sure you've got npm and grunt installed.

1. Copy Gruntfile.example.js to Gruntfile.js
2. Open Gruntfile.js and fill in your details
3. run `grunt screeps` to upload the scripts.